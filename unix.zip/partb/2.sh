echo "file sin direory: "
ls -l

