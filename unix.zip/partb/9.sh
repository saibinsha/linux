

echo "Your username: $(echo $USER)"
echo "Current date and time: $(date)"
echo "Checking logged in users with who command:"
who
echo "Checking logged in users with w command:"
w
echo "Checking logged in users with id command:"
id -u
echo "Checking logged in users with users command:"
users
echo "Checking logged in users with finger command:"
finger

