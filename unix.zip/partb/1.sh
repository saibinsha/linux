echo "filesin the current directory are: "
ls-l

